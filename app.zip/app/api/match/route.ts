import { NextResponse } from 'next/server';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { preferences, availableMentors } = body;

    const prompt = `
      As a mentorship matching expert, analyze these preferences from a mentee:
      - Location/Work Mode Preference: ${preferences.location}
      - Area of Interest: ${preferences.interest}
      - Experience Level: ${preferences.experience}
      - Mentorship Type: ${preferences.mentorshipType}

      Available mentors and their details:
      ${JSON.stringify(availableMentors, null, 2)}

      Based on these preferences and available mentors:
      1. Find the best matching mentor considering ALL criteria
      2. Explain why they are the best match
      3. Consider location/work mode compatibility
      4. Consider expertise alignment
      5. Consider experience level appropriateness
      6. Consider mentorship style fit

      Return response as JSON with these exact fields:
      {
        "selectedMentor": {mentor's full profile},
        "matchReason": "detailed explanation of why this mentor is the best match",
        "compatibilityScore": "percentage match based on all criteria"
      }
    `;

    const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer 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`,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'http://localhost:3000',
      },
      body: JSON.stringify({
        model: "meta-llama/llama-3.1-8b-instruct",
        messages: [
          { 
            role: "system", 
            content: "You are an expert mentorship matching system that analyzes mentor profiles and mentee preferences to find optimal matches. Always respond with valid JSON."
          },
          { role: "user", content: prompt }
        ],
        temperature: 0.5,
        max_tokens: 1000
      })
    });

    const data = await response.json();
    return NextResponse.json({ result: data.choices[0].message.content });
  } catch (error) {
    console.error('API Error:', error);
    return NextResponse.json({ error: 'Matching failed' }, { status: 500 });
  }
}